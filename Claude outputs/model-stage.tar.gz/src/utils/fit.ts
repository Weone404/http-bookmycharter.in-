import { Box3, Sphere, Vector3, type Object3D } from 'three';

/**
 * A model's measured size, in world units after its registry transform.
 *
 * Every camera shot and every hotspot in this system is expressed relative to
 * these numbers rather than in absolute units. That is the single decision
 * that makes the viewer model-agnostic: a glTF exported in millimetres and one
 * exported in metres frame identically, and a shot authored for a helicopter
 * is still a sensible shot for a wristwatch.
 */
export interface ModelBounds {
  readonly center: Vector3;
  readonly size: Vector3;
  readonly radius: Vector3['x'];
  readonly min: Vector3;
  readonly max: Vector3;
}

export function measure(object: Object3D): ModelBounds {
  const box = new Box3().setFromObject(object);
  const sphere = box.getBoundingSphere(new Sphere());
  return {
    center: box.getCenter(new Vector3()),
    size: box.getSize(new Vector3()),
    radius: sphere.radius,
    min: box.min.clone(),
    max: box.max.clone(),
  };
}

/** Converts a normalised shot position into world space. */
export function shotToWorld(
  bounds: ModelBounds,
  offset: readonly [number, number, number],
): Vector3 {
  return new Vector3(
    bounds.center.x + offset[0] * bounds.radius,
    bounds.center.y + offset[1] * bounds.radius,
    bounds.center.z + offset[2] * bounds.radius,
  );
}

/** Converts a bounding-box fraction into world space. */
export function fractionToWorld(
  bounds: ModelBounds,
  at: readonly [number, number, number],
): Vector3 {
  return new Vector3(
    bounds.min.x + at[0] * bounds.size.x,
    bounds.min.y + at[1] * bounds.size.y,
    bounds.min.z + at[2] * bounds.size.z,
  );
}

/**
 * The distance at which an object of this radius fills `coverage` of the
 * vertical field of view. Used so a shot that reads well on a 16:9 desktop
 * does not crop the subject on a tall phone.
 */
export function distanceFor(radius: number, fovDegrees: number, coverage = 0.8): number {
  const fov = (fovDegrees * Math.PI) / 180;
  return radius / Math.max(coverage, 0.1) / Math.tan(fov / 2);
}
