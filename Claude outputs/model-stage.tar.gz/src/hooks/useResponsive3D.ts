import { useEffect, useState } from 'react';

export type DeviceTier = 'mobile' | 'tablet' | 'desktop';

export interface Responsive3D {
  readonly tier: DeviceTier;
  readonly reducedMotion: boolean;
  /** Which of the registry's two files to load. */
  readonly quality: 'high' | 'low';
  /** Upper bound on device pixel ratio. */
  readonly maxDpr: number;
  readonly shadows: boolean;
  /**
   * How much of the vertical field of view the model's bounding sphere fills.
   * Above 1 the sphere is allowed to overflow the frame, which is usually what
   * you want: for anything with a wide, thin span — a rotor disc, a wingspan —
   * the bounding sphere is mostly empty air, so framing the sphere exactly
   * leaves the actual subject looking small and distant.
   */
  readonly coverage: number;
  /**
   * Moves the subject vertically within the frame, in bounding-sphere units.
   * Negative values aim the camera lower, which lifts the subject up the
   * screen. A portrait phone needs this: the copy occupies the bottom half, so
   * a model centred in the viewport sits behind the headline.
   */
  readonly verticalBias: number;
}

/**
 * Device class, motion preference and the quality decisions that follow.
 *
 * The mobile branch loads the 512 px texture build. That is not a cosmetic
 * downgrade — it is the only lever that matters. Both files contain the same
 * 512,136 triangles; what differs is that 100 textures decode to roughly
 * 400 MB of GPU memory at 1024 px and about 100 MB at 512 px, and it is that
 * number, not the download, that ends a session on a mid-range phone.
 *
 * Read on mount and on change only. No resize handler runs per frame and no
 * layout is read inside the render loop.
 */
export function useResponsive3D(): Responsive3D {
  const [tier, setTier] = useState<DeviceTier>('desktop');
  const [reducedMotion, setReducedMotion] = useState(false);

  useEffect(() => {
    const mobile = window.matchMedia('(max-width: 767px)');
    const tablet = window.matchMedia('(min-width: 768px) and (max-width: 1279px)');
    const motion = window.matchMedia('(prefers-reduced-motion: reduce)');

    const sync = () => {
      setTier(mobile.matches ? 'mobile' : tablet.matches ? 'tablet' : 'desktop');
      setReducedMotion(motion.matches);
    };

    sync();
    for (const query of [mobile, tablet, motion]) query.addEventListener('change', sync);
    return () => {
      for (const query of [mobile, tablet, motion]) query.removeEventListener('change', sync);
    };
  }, []);

  if (tier === 'mobile') {
    return { tier, reducedMotion, quality: 'low', maxDpr: 1.5, shadows: false, coverage: 0.56, verticalBias: -0.5 };
  }
  if (tier === 'tablet') {
    return { tier, reducedMotion, quality: 'high', maxDpr: 1.75, shadows: true, coverage: 1.05, verticalBias: -0.12 };
  }
  return { tier, reducedMotion, quality: 'high', maxDpr: 2, shadows: true, coverage: 1.35, verticalBias: 0 };
}
