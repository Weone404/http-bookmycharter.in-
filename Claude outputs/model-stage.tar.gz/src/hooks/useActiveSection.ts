import { useEffect, useState } from 'react';

/**
 * Which story section is currently in view.
 *
 * An IntersectionObserver rather than scroll arithmetic. Scroll maths has to
 * be recomputed on every resize, gets the answer wrong when sections have
 * different heights, and runs on the main thread during the one interaction
 * where jank is most visible. The observer is told once what to watch and
 * reports only when the answer changes.
 *
 * The page scrolls normally throughout. Nothing is pinned and nothing is
 * hijacked — the camera follows the reader rather than the reader being
 * dragged through a fixed sequence.
 */
export function useActiveSection(ids: readonly string[], fallback: string): string {
  const [active, setActive] = useState(fallback);

  useEffect(() => {
    const elements = ids
      .map((id) => document.getElementById(id))
      .filter((element): element is HTMLElement => element !== null);
    if (elements.length === 0) return;

    const visibility = new Map<string, number>();

    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          visibility.set(entry.target.id, entry.isIntersecting ? entry.intersectionRatio : 0);
        }
        let best = fallback;
        let bestRatio = 0;
        for (const [id, ratio] of visibility) {
          if (ratio > bestRatio) {
            best = id;
            bestRatio = ratio;
          }
        }
        if (bestRatio > 0) setActive(best);
      },
      {
        // Weighted towards the middle of the viewport, so the camera changes
        // when a section takes over the screen rather than when its first
        // pixel appears.
        rootMargin: '-35% 0px -35% 0px',
        threshold: [0, 0.25, 0.5, 0.75, 1],
      },
    );

    for (const element of elements) observer.observe(element);
    return () => observer.disconnect();
  }, [ids, fallback]);

  return active;
}
