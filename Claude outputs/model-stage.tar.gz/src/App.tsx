import { Suspense, lazy, useMemo, useState } from 'react';
import { DEFAULT_MODEL_ID, modelById } from '@/models/registry';
import type { CameraShot } from '@/models/types';
import { useActiveSection } from '@/hooks/useActiveSection';
import { Navbar } from '@/components/ui/Navbar';
import { Story } from '@/components/ui/Story';
import { Specifications } from '@/components/ui/Specifications';
import { HotspotPanel } from '@/components/ui/HotspotPanel';
import { SceneFallback } from '@/components/3d/SceneFallback';

/**
 * Three.js, the R3F reconciler and drei are about 1.2 MB of JavaScript, and
 * none of it is needed to paint the headline, the navigation or the
 * specifications. Loading it as a separate chunk means the written page — the
 * part that is actually the content — is interactive while the engine is
 * still arriving, and the gradient fallback fills the stage until it does.
 */
const ModelViewer = lazy(() =>
  import('@/components/3d/ModelViewer').then((m) => ({ default: m.ModelViewer })),
);


/**
 * Composition only.
 *
 * Which shot the camera should be in is derived from two inputs — the story
 * section in view, and whether a hotspot is selected — and a hotspot always
 * wins, because selecting one is a deliberate act and scrolling past a section
 * is not. Deriving it rather than storing it means there is no state to fall
 * out of sync when both change in the same frame.
 */
export default function App() {
  const model = modelById(DEFAULT_MODEL_ID);
  const [selected, setSelected] = useState<string | null>(null);

  const sectionIds = useMemo(() => (model ? model.story.map((s) => s.id) : []), [model]);
  const firstSection = model?.story[0]?.id ?? '';
  const active = useActiveSection(sectionIds, firstSection);

  if (!model) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#0a0c10] px-6 text-center">
        <p className="text-sm text-white/60">
          No model is registered under that id. Add one to <code>src/models/registry.ts</code>.
        </p>
      </main>
    );
  }

  const hotspot = model.hotspots.find((h) => h.id === selected) ?? null;
  const sectionShotId = model.story.find((s) => s.id === active)?.shotId;
  const fallbackShot: CameraShot = model.shots[0] ?? {
    id: 'default',
    position: [2, 0.6, 2],
    target: [0, 0, 0],
  };
  const shot: CameraShot =
    hotspot?.shot ?? model.shots.find((s) => s.id === sectionShotId) ?? fallbackShot;

  return (
    <>
      <Suspense fallback={<SceneFallback quiet />}>
        <ModelViewer
          model={model}
          shot={shot}
          activeHotspot={selected}
          onSelectHotspot={(id) => setSelected((current) => (current === id ? null : id))}
        />
      </Suspense>

      <Navbar model={model} sections={model.story} active={active} />

      <main>
        <Story model={model} />
        <Specifications model={model} />
      </main>

      <HotspotPanel hotspot={hotspot} onClose={() => setSelected(null)} />

      <footer className="relative px-5 pb-[max(2rem,env(safe-area-inset-bottom))] sm:px-8">
        <div className="mx-auto max-w-[92rem] border-t border-white/8 pt-6 text-[11px] text-white/30">
          Model Stage — a configuration-driven WebGL presentation framework. Adding a model is one
          entry in the registry.
        </div>
      </footer>
    </>
  );
}
