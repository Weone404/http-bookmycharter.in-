import type { ModelDefinition } from '@/models/types';

/**
 * The written page.
 *
 * Every word here is real HTML in the document, not text drawn into WebGL.
 * That is not an accessibility footnote: a heading rendered as geometry cannot
 * be selected, searched, translated, read by a screen reader or indexed, and a
 * page whose content only exists inside a canvas is a page with no content.
 * The 3D layer sits behind this and is marked `aria-hidden`.
 */
export function Story({ model }: { readonly model: ModelDefinition }) {
  return (
    <>
      {/* The hero deliberately leaves the right two-thirds of a wide viewport
          to the model. The copy column is narrow so the subject is never
          competing with a full-width block of text. */}
      <section
        id={model.story[0]?.id ?? 'intro'}
        className="relative flex min-h-[100svh] items-end px-5 pb-20 sm:px-8 lg:items-center lg:pb-0"
      >
        <div className="w-full max-w-[92rem] mx-auto">
          <div className="max-w-xl">
            <p className="text-[11px] font-medium tracking-[0.3em] text-white/45 uppercase">
              {model.category}
            </p>
            <h1 className="mt-5 text-[clamp(2.6rem,7vw,5.2rem)] leading-[0.95] font-light tracking-[-0.03em] text-white">
              {model.name}
            </h1>
            <p className="mt-6 max-w-md text-[15px] leading-relaxed text-white/60">
              {model.subtitle}
            </p>
            <div className="mt-9 flex flex-wrap items-center gap-3">
              <a
                href={`#${model.story[1]?.id ?? 'form'}`}
                className="rounded-full bg-white px-6 py-3 text-xs font-semibold tracking-[0.14em] text-[#0a0c10] uppercase transition hover:bg-white/85"
              >
                Explore
              </a>
              <a
                href="#specifications"
                className="rounded-full border border-white/25 px-6 py-3 text-xs font-medium tracking-[0.14em] text-white/75 uppercase transition hover:border-white/60 hover:text-white"
              >
                Specifications
              </a>
            </div>
          </div>
        </div>
      </section>

      {model.story.slice(1).map((section) => (
        <section
          key={section.id}
          id={section.id}
          className="relative flex min-h-[100svh] items-center px-5 sm:px-8"
        >
          <div className="mx-auto w-full max-w-[92rem]">
            <div className="max-w-lg rounded-2xl border border-white/10 bg-black/45 p-7 backdrop-blur-md sm:p-9">
              <p className="text-[11px] font-medium tracking-[0.28em] text-white/45 uppercase">
                {section.eyebrow}
              </p>
              <h2 className="mt-4 text-[clamp(1.6rem,3.4vw,2.6rem)] leading-[1.1] font-light tracking-[-0.02em] text-white">
                {section.heading}
              </h2>
              <p className="mt-5 text-[15px] leading-relaxed text-white/60">{section.body}</p>
            </div>
          </div>
        </section>
      ))}
    </>
  );
}
