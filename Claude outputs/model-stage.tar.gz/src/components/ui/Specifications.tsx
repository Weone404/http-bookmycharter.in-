import type { ModelDefinition } from '@/models/types';

export function Specifications({ model }: { readonly model: ModelDefinition }) {
  return (
    <section id="specifications" className="relative px-5 py-28 sm:px-8">
      <div className="mx-auto w-full max-w-[92rem]">
        <div className="rounded-2xl border border-white/10 bg-black/55 p-7 backdrop-blur-md sm:p-10">
          <p className="text-[11px] font-medium tracking-[0.28em] text-white/45 uppercase">
            Specifications
          </p>

          <div className="mt-10 grid gap-x-14 gap-y-12 md:grid-cols-2">
            {model.specifications.map((group) => (
              <div key={group.label}>
                <h2 className="text-sm font-medium tracking-[0.12em] text-white/80 uppercase">
                  {group.label}
                </h2>
                <dl className="mt-5">
                  {group.entries.map((entry) => (
                    <div
                      key={entry.name + entry.value}
                      className="flex justify-between gap-6 border-t border-white/8 py-2.5 text-sm"
                    >
                      <dt className="text-white/45">{entry.name}</dt>
                      <dd className="text-right tabular-nums text-white/85">{entry.value}</dd>
                    </div>
                  ))}
                </dl>
              </div>
            ))}
          </div>

          {/* Provenance is rendered, not filed away. An asset whose licence is
              unverified says so on the page rather than in a comment nobody
              reads, which is the only version of this that actually prevents
              shipping something unlicensed. */}
          <div className="mt-12 border-t border-white/10 pt-7 text-xs leading-relaxed text-white/40">
            <p>
              <span className="text-white/60">Asset source. </span>
              {model.provenance.source}
            </p>
            <p className="mt-1.5">
              <span className="text-white/60">Licence. </span>
              {model.provenance.licence}
              {model.provenance.verified ? null : (
                <span className="ml-2 rounded border border-amber-300/40 px-1.5 py-0.5 text-[10px] tracking-wide text-amber-200/90 uppercase">
                  Unverified — development use only
                </span>
              )}
            </p>
            {model.provenance.attribution ? (
              <p className="mt-1.5">
                <span className="text-white/60">Attribution. </span>
                {model.provenance.attribution}
              </p>
            ) : null}
          </div>
        </div>
      </div>
    </section>
  );
}
