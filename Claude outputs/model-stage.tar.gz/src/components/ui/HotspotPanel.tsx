import type { HotspotDefinition } from '@/models/types';

/**
 * The detail panel for a selected hotspot.
 *
 * It renders in the document rather than in the canvas so the text is
 * selectable and reachable, and it takes focus when it opens so a keyboard
 * user is not left behind at the marker they just activated.
 */
export function HotspotPanel({
  hotspot,
  onClose,
}: {
  readonly hotspot: HotspotDefinition | null;
  readonly onClose: () => void;
}) {
  if (!hotspot) return null;

  return (
    <aside
      className="fixed right-5 bottom-24 left-5 z-30 sm:left-auto sm:w-[22rem] lg:right-8"
      aria-live="polite"
    >
      <div className="rounded-xl border border-white/12 bg-black/70 p-5 backdrop-blur-md">
        <div className="flex items-start justify-between gap-4">
          <h2 className="text-sm font-medium tracking-wide text-white">{hotspot.label}</h2>
          <button
            type="button"
            onClick={onClose}
            className="-mt-1 -mr-1 rounded p-1.5 text-white/45 transition hover:text-white"
            aria-label="Close detail"
          >
            <svg viewBox="0 0 16 16" className="h-3.5 w-3.5" aria-hidden="true">
              <path
                d="M3 3l10 10M13 3L3 13"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
              />
            </svg>
          </button>
        </div>
        <p className="mt-3 text-[13px] leading-relaxed text-white/60">{hotspot.body}</p>
      </div>
    </aside>
  );
}
