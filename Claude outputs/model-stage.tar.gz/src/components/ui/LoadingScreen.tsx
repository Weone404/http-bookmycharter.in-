import { useProgress } from '@react-three/drei';
import { useEffect, useState } from 'react';

/**
 * The loading state for a 7.3 MB asset.
 *
 * Real progress, read from three's loading manager — not a fake bar that
 * animates to 90% and waits. It stays mounted for a moment after reaching 100%
 * so the panel fades rather than vanishing mid-decode, which is the point at
 * which the main thread is busiest and an instant disappearance looks like a
 * glitch.
 */
export function LoadingScreen() {
  const { active, progress, errors } = useProgress();
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    if (active || progress < 100) return;
    const timer = window.setTimeout(() => setVisible(false), 650);
    return () => window.clearTimeout(timer);
  }, [active, progress]);

  if (!visible) return null;
  const failed = errors.length > 0;

  return (
    <div
      className={`fixed inset-0 z-40 flex items-center justify-center bg-[#0a0c10] transition-opacity duration-500 ${
        !active && progress >= 100 ? 'opacity-0' : 'opacity-100'
      }`}
      role="status"
      aria-live="polite"
    >
      <div className="w-full max-w-xs px-6">
        <p className="text-[11px] font-medium tracking-[0.3em] text-white/45 uppercase">
          {failed ? 'Could not load' : 'Loading model'}
        </p>
        <p className="mt-3 text-5xl font-light tabular-nums text-white">
          {Math.round(progress)}
          <span className="text-2xl text-white/40">%</span>
        </p>
        <div className="mt-5 h-px w-full bg-white/12">
          <div
            className="h-px bg-white transition-[width] duration-300 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>
        <p className="mt-4 text-xs leading-relaxed text-white/40">
          {failed
            ? 'The asset could not be fetched or decoded. The written content below is unaffected.'
            : '512,136 triangles · Draco geometry · WebP textures'}
        </p>
      </div>
    </div>
  );
}
