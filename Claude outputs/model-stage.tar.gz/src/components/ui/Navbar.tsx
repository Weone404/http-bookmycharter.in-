import type { ModelDefinition } from '@/models/types';

export function Navbar({
  model,
  sections,
  active,
}: {
  readonly model: ModelDefinition;
  readonly sections: readonly { readonly id: string; readonly eyebrow: string }[];
  readonly active: string;
}) {
  return (
    <header className="fixed inset-x-0 top-0 z-30">
      <div className="mx-auto flex max-w-[92rem] items-center justify-between gap-6 px-5 pt-[max(1rem,env(safe-area-inset-top))] pb-4 sm:px-8">
        <a
          href="#intro"
          className="text-[13px] font-medium tracking-[0.18em] text-white uppercase"
        >
          Model&nbsp;Stage
        </a>

        <nav aria-label="Sections" className="hidden items-center gap-1 lg:flex">
          {sections.map((section) => (
            <a
              key={section.id}
              href={`#${section.id}`}
              aria-current={active === section.id ? 'true' : undefined}
              className={`rounded-full px-3 py-1.5 text-[11px] tracking-[0.12em] uppercase transition ${
                active === section.id
                  ? 'bg-white/12 text-white'
                  : 'text-white/45 hover:text-white/80'
              }`}
            >
              {section.eyebrow.split('—')[1]?.trim() ?? section.eyebrow}
            </a>
          ))}
        </nav>

        <p className="hidden text-right text-[11px] leading-tight text-white/40 sm:block">
          {model.name}
          <br />
          <span className="text-white/25">{model.category}</span>
        </p>
      </div>
    </header>
  );
}
