import { useEffect, useMemo, useRef } from 'react';
import { useGLTF } from '@react-three/drei';
import { useFrame } from '@react-three/fiber';
import { Group, Mesh, MeshStandardMaterial } from 'three';
import type { ModelDefinition } from '@/models/types';
import { measure, type ModelBounds } from '@/utils/fit';

useGLTF.preload('/models/optimized/gazelle-1024.glb');

/**
 * Loads a Draco-compressed glTF and hands back its measured bounds.
 *
 * Three things happen here and nowhere else.
 *
 * The decoder is served from `/draco/`, copied out of three's own package at
 * build time rather than pulled from a CDN. A viewer whose model silently
 * fails to decode because a third-party host is unreachable is worse than one
 * with a slightly larger repository.
 *
 * Materials are used exactly as authored. No material is replaced, recoloured
 * or simplified — the point of a 91-material asset is those 91 materials. The
 * only change made is to mark them for correct shadow behaviour, which is a
 * render setting, not an authored property.
 *
 * Procedural motion is applied to meshes named by index in the registry,
 * because this asset's exporter destroyed the node names. In development the
 * mesh list is logged once so indices can be found by looking rather than
 * guessed.
 */
export function ModelLoader({
  model,
  quality,
  motion,
  onMeasured,
}: {
  readonly model: ModelDefinition;
  readonly quality: 'high' | 'low';
  /** 0 stops all procedural motion. Used for prefers-reduced-motion. */
  readonly motion: number;
  readonly onMeasured: (bounds: ModelBounds) => void;
}) {
  const url = quality === 'high' ? model.files.high : model.files.low;
  const { scene } = useGLTF(url, '/draco/');
  const root = useRef<Group>(null);

  // A cloned scene per mount: useGLTF caches by URL, and mutating the cached
  // scene would leak state between mounts of the same model.
  const object = useMemo(() => scene.clone(true), [scene]);

  const meshes = useMemo(() => {
    const found: Mesh[] = [];
    object.traverse((child) => {
      if (child instanceof Mesh) {
        child.castShadow = true;
        child.receiveShadow = true;
        const material = child.material;
        if (material instanceof MeshStandardMaterial) {
          // Sketchfab exports frequently arrive single-sided with inverted
          // winding on thin parts; leaving this alone would punch holes in
          // canopies and rotor blades at grazing angles.
          material.shadowSide = material.side;
        }
        found.push(child);
      }
    });
    return found;
  }, [object]);

  useEffect(() => {
    if (!root.current) return;
    onMeasured(measure(root.current));
    if (import.meta.env.DEV) {
      // eslint-disable-next-line no-console
      console.info(
        `[model-stage] ${model.id}: ${meshes.length} meshes`,
        meshes.map((mesh, index) => `${index}:${mesh.name || '(unnamed)'}`),
      );
    }
  }, [meshes, model.id, onMeasured]);

  useFrame((_, rawDelta) => {
    if (motion === 0 || model.spins.length === 0) return;
    const delta = Math.min(rawDelta, 1 / 30);
    for (const spin of model.spins) {
      const mesh = meshes[spin.matchIndex];
      if (!mesh) continue;
      mesh.rotation[spin.axis] += spin.speed * motion * delta;
    }
  });

  const transform = model.transform ?? {};

  return (
    <group
      ref={root}
      scale={transform.scale ?? 1}
      position={transform.position ? [...transform.position] : [0, 0, 0]}
      rotation={transform.rotation ? [...transform.rotation] : [0, 0, 0]}
    >
      <primitive object={object} />
    </group>
  );
}
