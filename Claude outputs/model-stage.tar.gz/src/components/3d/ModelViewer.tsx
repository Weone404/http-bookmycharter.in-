import { Component, Suspense, useCallback, useEffect, useRef, useState } from 'react';
import type { ErrorInfo, ReactNode } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Preload } from '@react-three/drei';
import { ACESFilmicToneMapping } from 'three';
import type { CameraShot, ModelDefinition } from '@/models/types';
import type { ModelBounds } from '@/utils/fit';
import { useResponsive3D } from '@/hooks/useResponsive3D';
import { ModelLoader } from './ModelLoader';
import { ModelLighting } from './ModelLighting';
import { CameraRig } from './CameraRig';
import { Hotspot } from './Hotspot';
import { LoadingScreen } from '@/components/ui/LoadingScreen';
import { SceneFallback } from './SceneFallback';

/**
 * One canvas for the whole page.
 *
 * A browser hands out a small number of live WebGL contexts and each one
 * carries its own renderer, render loop and GPU allocation. A grid of canvases
 * is the fastest way to make a 3D site unusable, so the canvas is created once
 * here and every scene is a change of contents, not a new context.
 */

function supportsWebGl(): boolean {
  try {
    const canvas = document.createElement('canvas');
    return Boolean(
      window.WebGLRenderingContext &&
        (canvas.getContext('webgl2') ?? canvas.getContext('webgl')),
    );
  } catch {
    return false;
  }
}

/**
 * A failed model must not take the page with it.
 *
 * A thrown loader — a 404, a corrupt file, a decoder that would not
 * instantiate — unmounts the scene and leaves the surrounding HTML, which is
 * where all the actual content is, untouched.
 */
class SceneBoundary extends Component<
  { children: ReactNode; onError: (message: string) => void },
  { failed: boolean }
> {
  state = { failed: false };

  static getDerivedStateFromError() {
    return { failed: true };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    this.props.onError(error.message);
    if (import.meta.env.DEV) {
      // eslint-disable-next-line no-console
      console.error('[model-stage] scene failed', error, info.componentStack);
    }
  }

  render() {
    return this.state.failed ? null : this.props.children;
  }
}

export function ModelViewer({
  model,
  shot,
  activeHotspot,
  onSelectHotspot,
}: {
  readonly model: ModelDefinition;
  readonly shot: CameraShot;
  readonly activeHotspot: string | null;
  readonly onSelectHotspot: (id: string) => void;
}) {
  const responsive = useResponsive3D();
  const [capable, setCapable] = useState<boolean | null>(null);
  const [bounds, setBounds] = useState<ModelBounds | null>(null);
  const [inspect, setInspect] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const pointer = useRef({ x: 0, y: 0 });

  useEffect(() => setCapable(supportsWebGl()), []);

  useEffect(() => {
    if (responsive.reducedMotion) return;
    const onMove = (event: PointerEvent) => {
      if (event.pointerType !== 'mouse') return;
      pointer.current.x = (event.clientX / window.innerWidth) * 2 - 1;
      pointer.current.y = -((event.clientY / window.innerHeight) * 2 - 1);
    };
    window.addEventListener('pointermove', onMove, { passive: true });
    return () => window.removeEventListener('pointermove', onMove);
  }, [responsive.reducedMotion]);

  const onMeasured = useCallback((next: ModelBounds) => setBounds(next), []);

  if (capable === false || error) {
    return <SceneFallback reason={error ?? 'This browser cannot run WebGL.'} />;
  }

  return (
    <div className="fixed inset-0 -z-10">
      <SceneFallback quiet />

      {capable === true ? (
        <Canvas
          // Clamped, not device-native. On a 3× display an unclamped canvas
          // renders nine times the pixels for a difference nobody can see.
          dpr={[1, responsive.maxDpr]}
          shadows={responsive.shadows}
          camera={{ fov: 35, near: 0.01, far: 2000, position: [4, 2, 4] }}
          gl={{ antialias: true, powerPreference: 'high-performance', alpha: false, stencil: false }}
          onCreated={({ gl }) => {
            gl.toneMapping = ACESFilmicToneMapping;
            gl.toneMappingExposure = 1.35;
          }}
          aria-hidden="true"
          role="presentation"
        >
          <color attach="background" args={['#0a0c10']} />
          {/* Scaled to the subject like every other distance here. A fixed
              near/far would swallow a small model and do nothing to a large
              one. */}
          {bounds ? (
            <fog attach="fog" args={['#0a0c10', bounds.radius * 3, bounds.radius * 14]} />
          ) : null}

          <SceneBoundary onError={setError}>
            <Suspense fallback={null}>
              <ModelLoader
                model={model}
                quality={responsive.quality}
                motion={responsive.reducedMotion ? 0 : 1}
                onMeasured={onMeasured}
              />
              {bounds ? (
                <>
                  <ModelLighting
                    preset={model.lighting}
                    radius={bounds.radius}
                    groundY={bounds.min.y}
                    shadows={responsive.shadows}
                  />
                  {model.hotspots.map((hotspot, index) => (
                    <Hotspot
                      key={hotspot.id}
                      hotspot={hotspot}
                      index={index}
                      bounds={bounds}
                      active={activeHotspot === hotspot.id}
                      onSelect={onSelectHotspot}
                    />
                  ))}
                </>
              ) : null}
              <Preload all />
            </Suspense>
          </SceneBoundary>

          <CameraRig
            shot={shot}
            bounds={bounds}
            inspect={inspect}
            pointer={pointer}
            coverage={responsive.coverage}
            verticalBias={responsive.verticalBias}
            reducedMotion={responsive.reducedMotion}
          />

          {/* Enabled only in inspect mode. See the note in CameraRig: exactly
              one system writes the camera at any moment. */}
          <OrbitControls
            enabled={inspect}
            enablePan={false}
            enableDamping
            dampingFactor={0.08}
            minDistance={bounds ? bounds.radius * 1.1 : 1}
            maxDistance={bounds ? bounds.radius * 6 : 100}
            maxPolarAngle={Math.PI * 0.52}
            {...(bounds ? { target: [bounds.center.x, bounds.center.y, bounds.center.z] } : {})}
          />
        </Canvas>
      ) : null}

      <LoadingScreen />

      <div className="pointer-events-none fixed inset-x-0 bottom-0 z-20 flex justify-center pb-[max(1.25rem,env(safe-area-inset-bottom))]">
        <button
          type="button"
          onClick={() => setInspect((value) => !value)}
          className={`pointer-events-auto rounded-full border px-5 py-2.5 text-xs font-medium tracking-[0.14em] uppercase backdrop-blur transition ${
            inspect
              ? 'border-amber-300/70 bg-amber-300/15 text-amber-100'
              : 'border-white/20 bg-black/50 text-white/75 hover:border-white/50 hover:text-white'
          }`}
        >
          {inspect ? 'Exit free look' : 'Free look'}
        </button>
      </div>
    </div>
  );
}
