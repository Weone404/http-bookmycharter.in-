import { useEffect, useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { PerspectiveCamera, Vector3 } from 'three';
import gsap from 'gsap';
import type { CameraShot } from '@/models/types';
import { distanceFor, shotToWorld, type ModelBounds } from '@/utils/fit';

/**
 * The only thing that writes the camera — except when it deliberately isn't.
 *
 * Two owners of one property is the defect that makes 3D sites feel broken:
 * a scroll handler and an orbit control fighting over `camera.position`
 * produces drift, snapping and a camera that ends up somewhere nobody chose.
 * So there is exactly one rule here. In story mode this rig writes the camera
 * and `OrbitControls` is disabled. In inspect mode `OrbitControls` writes the
 * camera and this rig writes nothing at all. The handover re-reads the camera
 * on the way back so control returns from wherever the user left it, with no
 * jump.
 *
 * GSAP tweens the rig's own target vectors rather than the camera, and the
 * frame loop applies them. That keeps easing in one system and per-frame
 * application in another, instead of letting a tween and a render loop both
 * assign to the same object.
 */
export function CameraRig({
  shot,
  bounds,
  inspect,
  pointer,
  coverage,
  verticalBias,
  reducedMotion,
}: {
  readonly shot: CameraShot;
  readonly bounds: ModelBounds | null;
  readonly inspect: boolean;
  readonly pointer: { readonly current: { x: number; y: number } };
  readonly coverage: number;
  readonly verticalBias: number;
  readonly reducedMotion: boolean;
}) {
  const camera = useThree((state) => state.camera);
  const desired = useRef(new Vector3());
  const lookAt = useRef(new Vector3());
  const applied = useRef(new Vector3());
  const ready = useRef(false);

  useEffect(() => {
    if (!bounds) return;

    const fov = shot.fov ?? 35;
    const raw = shotToWorld(bounds, shot.position);

    // Re-seat the shot along its own direction so the subject fills the same
    // proportion of frame whatever the aspect ratio or model size. Without
    // this a shot authored on a desktop crops the subject on a phone.
    const direction = raw.clone().sub(bounds.center).normalize();
    const target = shotToWorld(bounds, shot.target);
    // Aiming lower lifts the subject up the frame; see verticalBias.
    target.y += verticalBias * bounds.radius;
    const distance = distanceFor(bounds.radius, fov, coverage);
    const position = bounds.center.clone().add(direction.multiplyScalar(distance));

    if (camera instanceof PerspectiveCamera && camera.fov !== fov) {
      camera.fov = fov;
      camera.updateProjectionMatrix();
    }

    if (!ready.current) {
      desired.current.copy(position);
      lookAt.current.copy(target);
      applied.current.copy(position);
      camera.position.copy(position);
      camera.lookAt(target);
      ready.current = true;
      return;
    }

    if (reducedMotion) {
      desired.current.copy(position);
      lookAt.current.copy(target);
      return;
    }

    gsap.to(desired.current, {
      x: position.x,
      y: position.y,
      z: position.z,
      duration: 1.5,
      ease: 'power3.inOut',
      overwrite: true,
    });
    gsap.to(lookAt.current, {
      x: target.x,
      y: target.y,
      z: target.z,
      duration: 1.5,
      ease: 'power3.inOut',
      overwrite: true,
    });
  }, [shot, bounds, camera, coverage, verticalBias, reducedMotion]);

  // Leaving inspect mode: adopt wherever the user left the camera, so the
  // tween back to the current shot starts from the truth rather than from a
  // stale value.
  useEffect(() => {
    if (inspect) applied.current.copy(camera.position);
  }, [inspect, camera]);

  useFrame((_, rawDelta) => {
    if (inspect || !ready.current) return;
    const delta = Math.min(rawDelta, 1 / 30);
    const alpha = 1 - Math.exp(-6 * delta);

    // Pointer parallax is an offset applied on top of the tweened position,
    // never written back into it, so it can never accumulate.
    const sway = reducedMotion ? 0 : bounds ? bounds.radius * 0.05 : 0;
    const targetX = desired.current.x + pointer.current.x * sway;
    const targetY = desired.current.y + pointer.current.y * sway * 0.6;

    applied.current.x += (targetX - applied.current.x) * alpha;
    applied.current.y += (targetY - applied.current.y) * alpha;
    applied.current.z += (desired.current.z - applied.current.z) * alpha;

    camera.position.copy(applied.current);
    camera.lookAt(lookAt.current);
  });

  return null;
}
