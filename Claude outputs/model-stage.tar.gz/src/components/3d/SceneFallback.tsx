/**
 * What fills the stage when WebGL is unavailable, or when the scene threw.
 *
 * Never a blank screen and never an apology. `quiet` renders only the
 * atmosphere, so it can sit behind a working canvas and guarantee there is no
 * unpainted frame between mount and first render.
 */
export function SceneFallback({
  quiet = false,
  reason,
}: {
  readonly quiet?: boolean;
  readonly reason?: string;
}) {
  return (
    <div className="fixed inset-0 -z-10 overflow-hidden bg-[#0a0c10]" aria-hidden={quiet}>
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_58%_42%,rgba(120,160,200,0.16),transparent_62%)]" />
      <div className="absolute inset-x-0 bottom-[38%] h-px bg-gradient-to-r from-transparent via-white/15 to-transparent" />
      <div
        className="absolute inset-x-0 bottom-0 h-[38%] opacity-[0.06]"
        style={{
          backgroundImage:
            'linear-gradient(to right, #ffffff 1px, transparent 1px), linear-gradient(to top, #ffffff 1px, transparent 1px)',
          backgroundSize: '4rem 4rem',
        }}
      />

      {!quiet && reason ? (
        <div className="absolute inset-x-0 top-1/2 mx-auto max-w-md -translate-y-1/2 px-6 text-center">
          <p className="text-sm text-white/70">
            The three-dimensional view could not start. {reason}
          </p>
          <p className="mt-3 text-sm text-white/45">
            Everything on this page is written text and is unaffected.
          </p>
        </div>
      ) : null}
    </div>
  );
}
