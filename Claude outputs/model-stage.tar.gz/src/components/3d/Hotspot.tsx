import { Html } from '@react-three/drei';
import type { HotspotDefinition } from '@/models/types';
import { fractionToWorld, type ModelBounds } from '@/utils/fit';

/**
 * A point of interest anchored to the model.
 *
 * Two deliberate choices, both of them corrections to what the first version
 * actually rendered.
 *
 * The marker is a numbered dot, and the label appears only when it is active
 * or hovered. Four permanent labels floating over a hero shot is noise: it
 * hides the subject the page exists to show, and the labels collide with each
 * other the moment the camera moves.
 *
 * There is no `occlude`. drei's blending occlusion composites the overlay
 * through a mask, and when that mask is wrong — which it was here, shredding
 * every label into two-character fragments — the failure is silent and looks
 * like a font bug. Annotation markers that draw over the subject are the
 * normal convention anyway; a marker the user cannot find is worse than one
 * that floats.
 *
 * The marker is a real `<button>` in the DOM overlay, so it is focusable,
 * activates on Enter and Space, and is announced. A hotspot drawn as a sprite
 * would look identical and be unreachable without a mouse.
 */
export function Hotspot({
  hotspot,
  index,
  bounds,
  active,
  onSelect,
}: {
  readonly hotspot: HotspotDefinition;
  readonly index: number;
  readonly bounds: ModelBounds;
  readonly active: boolean;
  readonly onSelect: (id: string) => void;
}) {
  const position = fractionToWorld(bounds, hotspot.at);

  return (
    <Html position={position} center zIndexRange={[20, 10]}>
      <button
        type="button"
        onClick={() => onSelect(hotspot.id)}
        aria-pressed={active}
        aria-label={hotspot.label}
        className={`group flex items-center gap-2 rounded-full border p-0.5 pr-0.5 backdrop-blur transition-all ${
          active
            ? 'border-amber-300/70 bg-amber-300/15'
            : 'border-white/30 bg-black/45 hover:border-white/70'
        }`}
      >
        <span
          className={`flex h-6 w-6 items-center justify-center rounded-full text-[10px] font-semibold tabular-nums ${
            active ? 'bg-amber-300 text-[#0a0c10]' : 'bg-white/85 text-[#0a0c10]'
          }`}
          aria-hidden="true"
        >
          {index + 1}
        </span>
        <span
          className={`max-w-0 overflow-hidden pr-0 text-[11px] font-medium whitespace-nowrap text-white/90 transition-all duration-300 group-hover:max-w-[14rem] group-hover:pr-3 group-focus-visible:max-w-[14rem] group-focus-visible:pr-3 ${
            active ? 'max-w-[14rem] pr-3' : ''
          }`}
          aria-hidden="true"
        >
          {hotspot.label}
        </span>
      </button>
    </Html>
  );
}
