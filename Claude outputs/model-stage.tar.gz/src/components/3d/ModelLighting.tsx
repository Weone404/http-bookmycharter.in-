import { Environment, Lightformer, ContactShadows } from '@react-three/drei';
import type { LightingPreset } from '@/models/types';

/**
 * Lighting, built entirely in-scene.
 *
 * Deliberately no HDRI download. drei's `Environment preset` fetches a several
 * megabyte `.hdr` from a third-party CDN, which adds a blocking external
 * request to a page whose whole argument is that it ships 7.3 MB and needs
 * nothing else. `Lightformer` meshes rendered into an environment map give a
 * comparable result for a controlled studio subject, cost one small offscreen
 * render, and work offline.
 *
 * Each preset is a different answer to the same question — where is the light
 * coming from — rather than a different brightness of the same setup.
 */
export function ModelLighting({
  preset,
  radius,
  groundY,
  shadows,
}: {
  readonly preset: LightingPreset;
  /** The subject's bounding-sphere radius, so rigs scale with the model. */
  readonly radius: number;
  readonly groundY: number;
  readonly shadows: boolean;
}) {
  const r = Math.max(radius, 0.001);

  return (
    <>
      <Environment resolution={256} frames={1}>
        {preset === 'studio' ? (
          <>
            <Lightformer form="rect" intensity={4} position={[0, r * 3, r * 2]} scale={[r * 4, r * 3, 1]} />
            <Lightformer form="rect" intensity={2} position={[-r * 3, r * 1.5, 0]} scale={[r * 3, r * 3, 1]} rotation-y={Math.PI / 2} />
            <Lightformer form="rect" intensity={2} position={[r * 3, r * 1.5, 0]} scale={[r * 3, r * 3, 1]} rotation-y={-Math.PI / 2} />
          </>
        ) : null}

        {preset === 'cinematic' ? (
          <>
            {/* One dominant key from high and behind, a cool rim opposite it,
                and a weak fill: the arrangement that reads as expensive
                because it leaves most of the subject in controlled shadow. */}
            <Lightformer form="rect" intensity={14} color="#fff3e2" position={[r * 2, r * 3, -r * 2]} scale={[r * 3, r * 2, 1]} rotation-x={Math.PI / 4} />
            <Lightformer form="rect" intensity={6} color="#9fd6ff" position={[-r * 3, r * 1.2, -r * 2]} scale={[r * 4, r * 2, 1]} rotation-y={Math.PI / 3} />
            <Lightformer form="rect" intensity={2.6} color="#ffffff" position={[0, r * 0.6, r * 4]} scale={[r * 5, r * 2, 1]} />
            <Lightformer form="ring" intensity={4} color="#ffffff" position={[r * 2.5, r * 2, r * 3]} scale={r * 1.2} />
          </>
        ) : null}

        {preset === 'technical' ? (
          <>
            <Lightformer form="rect" intensity={3} position={[0, r * 4, 0]} scale={[r * 6, r * 6, 1]} rotation-x={Math.PI / 2} />
            <Lightformer form="rect" intensity={1.6} position={[0, 0, r * 4]} scale={[r * 5, r * 5, 1]} />
            <Lightformer form="rect" intensity={1.6} position={[0, 0, -r * 4]} scale={[r * 5, r * 5, 1]} rotation-y={Math.PI} />
          </>
        ) : null}

        {preset === 'daylight' ? (
          <>
            <Lightformer form="rect" intensity={9} color="#fffaf0" position={[r * 3, r * 4, r * 2]} scale={[r * 2, r * 2, 1]} />
            <Lightformer form="rect" intensity={1.4} color="#bcd9ff" position={[0, r * 5, 0]} scale={[r * 8, r * 8, 1]} rotation-x={Math.PI / 2} />
          </>
        ) : null}
      </Environment>

      {/* A single real shadow-casting light. Everything above is reflected
          illumination; without one directional source there is no contact
          between the subject and the ground. */}
      <directionalLight
        castShadow={shadows}
        position={[r * 2.5, r * 3.5, r * 2]}
        intensity={preset === 'technical' ? 1.2 : 3.4}
        shadow-mapSize={[2048, 2048]}
        shadow-bias={-0.0006}
        shadow-normalBias={0.02}
      >
        <orthographicCamera
          attach="shadow-camera"
          args={[-r * 1.8, r * 1.8, r * 1.8, -r * 1.8, 0.1, r * 12]}
        />
      </directionalLight>
      <ambientLight intensity={preset === 'technical' ? 0.8 : 0.45} />

      {shadows ? (
        <ContactShadows
          position={[0, groundY - r * 0.005, 0]}
          scale={r * 4}
          resolution={1024}
          blur={2.4}
          opacity={0.7}
          far={r * 2}
          frames={1}
        />
      ) : null}
    </>
  );
}
