import type { ModelDefinition } from './types';

/**
 * Every presentable model. Adding one is an entry here and two files in
 * `public/models/optimized/` — no component is touched.
 */

const GAZELLE: ModelDefinition = {
  id: 'sa342m-gazelle',
  name: 'SA 342M Gazelle',
  subtitle: 'Aérospatiale · light observation and anti-tank helicopter',
  category: 'helicopter',

  files: {
    high: '/models/optimized/gazelle-1024.glb',
    low: '/models/optimized/gazelle-512.glb',
  },

  transform: { scale: 1, position: [0, 0, 0], rotation: [0, 0, 0] },
  lighting: 'cinematic',

  shots: [
    { id: 'hero', position: [2.05, 0.52, 1.95], target: [-0.22, 0.04, 0], fov: 34 },
    { id: 'profile', position: [0.1, 0.18, 2.85], target: [0, 0, 0], fov: 30 },
    { id: 'rotor', position: [1.25, 1.15, 1.25], target: [0, 0.34, 0], fov: 36 },
    { id: 'cockpit', position: [-1.55, 0.3, 1.05], target: [-0.18, 0.06, 0], fov: 32 },
    { id: 'tail', position: [1.6, 0.35, 1.5], target: [0.3, 0.06, 0], fov: 34 },
    { id: 'top', position: [0.4, 2.4, 0.5], target: [0, 0, 0], fov: 36 },
  ],

  // Bounding-box fractions, corrected against a render rather than assumed:
  // the first pass had the nose at +X and put the fenestron marker on a main
  // rotor blade. The aircraft's nose is at -X.
  // See the comment on HotspotDefinition for why these are not node names.
  hotspots: [
    {
      id: 'rotor',
      label: 'Three-blade main rotor',
      body: 'A 10.50 m rigid-head rotor. In the source asset the blades are static geometry with no animation track, so the rotation here is applied procedurally by the viewer rather than played back from the file.',
      at: [0.5, 0.94, 0.5],
      shot: { id: 'rotor-focus', position: [1.1, 0.95, 1.1], target: [0, 0.36, 0], fov: 34 },
    },
    {
      id: 'fenestron',
      label: 'Fenestron tail rotor',
      body: 'The Gazelle was the first production helicopter to use a shrouded fan in the tail fin instead of an exposed tail rotor — the feature the type is best known for.',
      at: [0.94, 0.63, 0.5],
      shot: { id: 'tail-focus', position: [1.35, 0.42, 0.95], target: [0.38, 0.12, 0], fov: 30 },
    },
    {
      id: 'cockpit',
      label: 'Two-seat cockpit',
      body: 'Crew of two under a wraparound glazed canopy. The glazing is a separate transparent material in the asset, which is why it renders with real depth sorting rather than as an opaque shell.',
      at: [0.14, 0.45, 0.5],
      shot: { id: 'cockpit-focus', position: [-1.5, 0.3, 0.95], target: [-0.22, 0.05, 0], fov: 30 },
    },
    {
      id: 'skids',
      label: 'Skid landing gear',
      body: 'Fixed tubular skids. Their fine cross-bracing is a good test of whether the geometry survived compression — Draco is lossless on topology, so it should be intact at every zoom level.',
      at: [0.5, 0.05, 0.5],
      shot: { id: 'skid-focus', position: [1.2, 0.18, 1.25], target: [0, -0.12, 0], fov: 32 },
    },
  ],

  // Mesh 33 is the main rotor disc, identified by measuring every mesh in the
  // optimised file rather than by guessing: its local bounding box is
  // 9.24 x 8.08 x 0.44 units — wide on two axes, thin on the third — which is
  // the signature of a rotor disc and is consistent with the type's 10.50 m
  // rotor. The file is authored Z-up under a root node that rotates it, so the
  // disc's normal is local Z and that is the axis it turns about.
  //
  // 2.2 rad/s is a presentation speed, not a scale one. A Gazelle rotor turns
  // at about 387 rpm; rendered honestly at 60 fps that is roughly 6.5 turns
  // per frame-second, which strobes into a static or backwards-turning disc.
  spins: [{ matchIndex: 33, axis: 'z', speed: 2.2 }],

  specifications: [
    {
      label: 'Aircraft',
      entries: [
        { name: 'Manufacturer', value: 'Aérospatiale' },
        { name: 'Crew', value: '2' },
        { name: 'Powerplant', value: '1 × Turbomeca Astazou XIVM turboshaft' },
        { name: 'Power', value: '590 shp' },
        { name: 'Main rotor diameter', value: '10.50 m' },
        { name: 'Length', value: '9.53 m' },
        { name: 'Height', value: '3.18 m' },
        { name: 'Empty weight', value: '999 kg' },
        { name: 'Max takeoff weight', value: '2,000 kg' },
        { name: 'Maximum speed', value: '265 km/h' },
        { name: 'Cruise speed', value: '170 km/h' },
        { name: 'Range', value: '710 km' },
        { name: 'Rate of climb', value: '732 m/min' },
      ],
    },
    {
      label: 'Asset',
      entries: [
        { name: 'Triangles', value: '512,136' },
        { name: 'Vertices', value: '415,222' },
        { name: 'Meshes', value: '91' },
        { name: 'Materials', value: '91' },
        { name: 'Textures', value: '100' },
        { name: 'Source file', value: '93.8 MB' },
        { name: 'Delivered (desktop)', value: '7.3 MB' },
        { name: 'Delivered (mobile)', value: '4.7 MB' },
        { name: 'Geometry', value: 'Draco edgebreaker, lossless topology' },
        { name: 'Textures', value: 'WebP, 1024 px / 512 px' },
        { name: 'Animation tracks', value: 'None in source' },
      ],
    },
  ],

  story: [
    {
      id: 'intro',
      eyebrow: '01 — The subject',
      heading: 'Half a million triangles, delivered in 7.3 megabytes.',
      body: 'The source asset is a 93.8 MB glTF: 512,136 triangles across 97 meshes, 92 materials and 103 embedded textures. Nothing has been decimated. Every triangle you are looking at is in the original file; what changed is how the vertices and the textures are encoded.',
      shotId: 'hero',
    },
    {
      id: 'form',
      eyebrow: '02 — Form',
      heading: 'A silhouette designed around a shrouded tail fan.',
      body: 'The Gazelle was the first production helicopter to replace the exposed tail rotor with a fenestron — a fan enclosed in the fin. Rotate the model, or scroll on, and the profile shot puts the whole airframe against the light.',
      shotId: 'profile',
    },
    {
      id: 'rotor',
      eyebrow: '03 — Rotor',
      heading: 'No animation tracks. So the motion is computed, not played.',
      body: 'The file contains zero animations — a common outcome when a model passes through a mesh-merging exporter. Rather than pretend otherwise, the viewer drives motion procedurally, which is also what lets the same system spin a wheel, open a hatch or turn a turbine.',
      shotId: 'rotor',
    },
    {
      id: 'materials',
      eyebrow: '04 — Materials',
      heading: 'Ninety-one materials, none of them replaced.',
      body: 'Physically based materials are preserved exactly as authored: base colour, normal maps, metalness and roughness, transparent glazing and a clearcoat extension. Lighting comes from procedural area lights rather than a downloaded HDRI, so the scene needs no external request at all.',
      shotId: 'cockpit',
    },
    {
      id: 'scale',
      eyebrow: '05 — The system',
      heading: 'The viewer knows nothing about helicopters.',
      body: 'Camera shots are expressed as multiples of the model’s own bounding sphere, and hotspots as fractions of its bounding box. A car, a turbine or a wristwatch uses the same component, the same camera rig and the same loader — only the registry entry differs.',
      shotId: 'top',
    },
  ],

  provenance: {
    source: 'Supplied as sa342m_gazelle.glb — a Sketchfab export (generator: Sketchfab-0.10.0)',
    licence: 'Not yet verified',
    verified: false,
  },
};

export const MODELS: readonly ModelDefinition[] = [GAZELLE];

export function modelById(id: string): ModelDefinition | undefined {
  return MODELS.find((model) => model.id === id);
}

export const DEFAULT_MODEL_ID = GAZELLE.id;
