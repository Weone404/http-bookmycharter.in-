/**
 * The contract every presentable model satisfies.
 *
 * Everything the viewer needs comes from here, so adding a car, a turbine or a
 * product means adding one object to the registry — no component changes. The
 * inverse rule matters just as much: nothing in `components/3d` may contain a
 * fact about a specific model.
 */

/** A camera position expressed in the model's own bounding-box units. */
export interface CameraShot {
  readonly id: string;
  /**
   * Where the camera sits, as a multiple of the model's bounding-sphere
   * radius from its centre. Normalising against the model's own size is what
   * lets the same shot list work for a helicopter and a wristwatch.
   */
  readonly position: readonly [number, number, number];
  /** Where it looks, in the same normalised units, offset from centre. */
  readonly target: readonly [number, number, number];
  readonly fov?: number;
}

/**
 * An interactive point on the model.
 *
 * Positions are fractions of the axis-aligned bounding box — [0,0,0] is the
 * minimum corner, [1,1,1] the maximum. This is deliberate: the Sketchfab
 * export that prompted this system has node names like `Object_2_2`, its
 * material merger having destroyed the semantic hierarchy, so there is no
 * "rotor" node to attach to. Bounding-box fractions are authorable by looking
 * at the model, survive re-export, and work identically for every asset.
 */
export interface HotspotDefinition {
  readonly id: string;
  readonly label: string;
  readonly body: string;
  readonly at: readonly [number, number, number];
  /** Camera shot to fly to when this hotspot is selected. */
  readonly shot: CameraShot;
}

export interface SpecificationGroup {
  readonly label: string;
  readonly entries: readonly { readonly name: string; readonly value: string }[];
}

export type LightingPreset = 'studio' | 'cinematic' | 'technical' | 'daylight';

/**
 * Procedural spin applied to a mesh the loader could not identify by name.
 *
 * `matchIndex` is the index of the mesh within the loaded scene's mesh list.
 * Naming it by index rather than by name is not laziness — see the comment on
 * `HotspotDefinition`. An index has to be found by rendering the model and
 * looking at it, which is why this is optional and empty by default.
 */
export interface ProceduralSpin {
  readonly matchIndex: number;
  readonly axis: 'x' | 'y' | 'z';
  /** Radians per second at full speed. */
  readonly speed: number;
}

export interface ModelDefinition {
  readonly id: string;
  readonly name: string;
  readonly subtitle: string;
  readonly category: string;

  /**
   * Two texture resolutions of the same geometry. `low` is not a different
   * model — same 512,136 triangles — it exists because texture memory, not
   * download size, is what limits a phone.
   */
  readonly files: {
    readonly high: string;
    readonly low: string;
  };

  readonly transform?: {
    readonly scale?: number;
    readonly position?: readonly [number, number, number];
    readonly rotation?: readonly [number, number, number];
  };

  readonly lighting: LightingPreset;
  readonly shots: readonly CameraShot[];
  readonly hotspots: readonly HotspotDefinition[];
  readonly spins: readonly ProceduralSpin[];
  readonly specifications: readonly SpecificationGroup[];

  /** Narrative sections, in scroll order. Each names a shot by id. */
  readonly story: readonly {
    readonly id: string;
    readonly eyebrow: string;
    readonly heading: string;
    readonly body: string;
    readonly shotId: string;
  }[];

  /**
   * Where the asset came from and under what terms.
   *
   * Required, not optional. A model whose licence is unknown is a liability,
   * and `attribution` renders on the page whenever it is set, so a CC-BY asset
   * cannot be shipped without its credit by forgetting a step.
   */
  readonly provenance: {
    readonly source: string;
    readonly licence: string;
    readonly attribution?: string;
    readonly verified: boolean;
  };
}
