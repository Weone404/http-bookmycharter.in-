# Model Stage

A configuration-driven WebGL presentation framework. One canvas, one camera
authority, and a registry: adding a model is an entry in `src/models/registry.ts`
and two files in `public/models/optimized/`. No component contains a fact about
any specific model.

The reference asset is an SA 342M Gazelle, but nothing in `src/components/3d`
knows what a helicopter is.

---

## 1. Running it

```bash
npm install
npm run dev          # http://localhost:5173
npm run build        # typecheck, then production build into dist/
npm run preview      # serve dist/ on http://localhost:4173
npm run typecheck    # tsc --noEmit on its own
```

Requires Node 20 or newer.

---

## 2. Adding a model

Three steps.

**Optimise the source file.** Almost no model from a marketplace or an
authoring tool is a web asset as downloaded.

```bash
node scripts/optimize-model.mjs input.glb public/models/optimized/thing-1024.glb 1024
node scripts/optimize-model.mjs input.glb public/models/optimized/thing-512.glb  512
```

**Add a registry entry.** `src/models/types.ts` is the full contract. The
minimum is an id, a name, the two file paths, a lighting preset, at least one
camera shot, and provenance.

```ts
const THING: ModelDefinition = {
  id: 'thing',
  name: 'Thing',
  subtitle: 'What it is, in one line',
  category: 'product',
  files: { high: '/models/optimized/thing-1024.glb', low: '/models/optimized/thing-512.glb' },
  lighting: 'studio',
  shots: [{ id: 'hero', position: [2, 0.5, 2], target: [0, 0, 0], fov: 35 }],
  hotspots: [],
  spins: [],
  specifications: [],
  story: [{ id: 'intro', eyebrow: '01', heading: '…', body: '…', shotId: 'hero' }],
  provenance: { source: 'where it came from', licence: 'what terms', verified: false },
};
```

**Add it to `MODELS`** and point `DEFAULT_MODEL_ID` at it.

Two files, not one, is deliberate: see the texture-memory note in §8.

---

## 3. Configuring the camera

Shots are **normalised against the model's own bounding sphere**, so the same
numbers frame a helicopter and a wristwatch identically.

```ts
{ id: 'hero', position: [2.05, 0.52, 1.95], target: [-0.22, 0.04, 0], fov: 34 }
```

`position` and `target` are multiples of the bounding-sphere radius from the
model's centre. `fov` is in degrees.

The rig then re-seats the shot along its own direction so the subject fills
`coverage` of the vertical field of view — a per-device number in
`src/hooks/useResponsive3D.ts`. Coverage above 1 lets the bounding sphere
overflow the frame, which is usually what you want: for anything with a wide,
thin span the sphere is mostly empty air. `verticalBias` aims the camera lower
so the subject rides higher up a portrait screen.

**One rule about the camera, and it matters more than any of the above.** In
story mode `CameraRig` writes `camera.position` and `OrbitControls` is
disabled. In free-look mode `OrbitControls` writes it and the rig writes
nothing. Never both. Two owners of one property is what makes a 3D site feel
broken, and this codebase enforces the boundary rather than hoping.

Scroll position is read by an `IntersectionObserver`, not by scroll arithmetic.
The page scrolls normally throughout — nothing is pinned, nothing is hijacked.

---

## 4. Configuring lighting

`lighting` names one of four presets in `src/components/3d/ModelLighting.tsx`:
`studio`, `cinematic`, `technical`, `daylight`. Each is a different answer to
where the light comes from, not a different brightness of the same setup. All
of them scale with the model's radius.

**No HDRI is downloaded.** drei's `Environment preset` fetches several
megabytes from a third-party CDN. Here the environment is built from
`Lightformer` meshes rendered once into a 256 px environment map: it costs one
offscreen render, works offline, and means the whole page makes no external
request at all.

To add a preset, add a branch in `ModelLighting` and a value to
`LightingPreset` in `src/models/types.ts` — the compiler will find every place
that needs updating.

---

## 5. Adding animations

Check for animation tracks in the source file first. If they exist, play them
with `useAnimations`. **If they do not — and for mesh-merged exports they
usually do not — say so and drive the motion procedurally.**

```ts
spins: [{ matchIndex: 33, axis: 'z', speed: 2.2 }],
```

`matchIndex` is the mesh's position in scene-traversal order. Indices rather
than names, because exporters that merge materials routinely destroy the node
names — this asset's are `Object_2_2`, `Object_56`, `Object_190`.

Find the index by measuring, not guessing. The reference rotor was identified
by walking the optimised file and measuring every mesh's local bounding box:
mesh 33 is 9.24 × 8.08 × 0.44 units — wide on two axes, thin on the third —
which is the signature of a rotor disc and matches the type's 10.50 m rotor. In
development the loader also logs the full mesh list to the console.

Note the speed. A Gazelle rotor turns at roughly 387 rpm; rendered at that rate
on a 60 Hz display it strobes into a disc that looks static or turns backwards.
2.2 rad/s reads as a turning rotor, which is the honest choice for a
presentation and is labelled as such.

Under `prefers-reduced-motion` all procedural motion is passed `0` and stops.

---

## 6. Adding hotspots

Positions are **fractions of the model's axis-aligned bounding box** —
`[0,0,0]` is the minimum corner, `[1,1,1]` the maximum.

```ts
{
  id: 'fenestron',
  label: 'Fenestron tail rotor',
  body: '…',
  at: [0.94, 0.63, 0.5],
  shot: { id: 'tail-focus', position: [1.35, 0.42, 0.95], target: [0.38, 0.12, 0], fov: 30 },
}
```

Same reason as `matchIndex`: there is no `rotor` node to attach to. Bounding-box
fractions are authorable by looking at a render, survive re-export, and work
for every asset.

Author them, then **render and check**. The first pass here assumed the nose was
at +X and put the fenestron marker on a main rotor blade.

Markers are numbered dots that reveal their label on hover, focus or selection.
Each is a real `<button>` in the DOM overlay: focusable, keyboard-activated and
announced. Selecting one flies the camera to its shot, and a hotspot always
overrides the scroll position — clicking is deliberate, scrolling past is not.

---

## 7. The optimisation pipeline

`scripts/optimize-model.mjs` is the script that produced the shipped files.

Measured on the reference asset:

| | file | meshes | materials | textures | triangles |
|---|---|---|---|---|---|
| source | 93.8 MB | 97 | 92 | 103 | 512,136 |
| 1024 px | **7.3 MB** | 91 | 91 | 100 | 512,136 |
| 512 px | **4.7 MB** | 91 | 91 | 100 | 512,136 |

**The triangle count does not change.** No decimation is performed and none is
wanted: 92% is available from vertex encoding and texture format alone, and
simplification is the one step that is actually visible, so it is the last
thing to reach for rather than the first. The script warns if any transform
changes the triangle count.

Order matters. `dedup` before `join`, because joining first hides duplicates.
`prune` after both, because the earlier steps are what orphan the nodes worth
pruning. Texture compression last among the data steps, so it only runs on
textures that survived.

---

## 8. Building for production, and the one thing still unsolved

```bash
npm run build
```

`dist/` is static and can be served from anywhere. The Three.js, R3F and drei
chunks are split out and the viewer is lazily imported, so the headline,
navigation and specifications paint and become interactive before the engine
arrives.

**The unsolved part, stated plainly: texture memory.** The delivered files are
WebP. WebP is small on disk and decodes to full RGBA in GPU memory regardless —
roughly 400 MB of VRAM for this model's 100 textures at 1024 px, about 100 MB
at 512 px. That, not the download, is what ends a session on a mid-range phone,
and it is why the mobile tier loads the 512 px build.

The real fix is KTX2/Basis, which stays compressed on the GPU. It needs the
KTX-Software binaries (`toktx`) on PATH; with those installed, add the
transform to `scripts/optimize-model.mjs` and a `KTX2Loader` to `ModelLoader`.
Nothing else in the project changes. Until then the mobile path is mitigated,
not solved, and this README will keep saying so.

---

## 9. What is built, and what is not

Built and verified by rendering: model loading with a locally served Draco
decoder, measured bounds, the camera rig and its single-writer handover,
scroll-driven shots, hotspots with camera focus, procedural rotor motion
(confirmed by frame differencing, not asserted), four lighting presets, contact
shadows, real load progress, a WebGL-absent fallback, an error boundary around
the scene, reduced-motion handling, and responsive quality tiers.

Architected for but **not implemented**: model comparison, material and colour
configuration, exploded views, measurement tools, component isolation, X-ray
and wireframe modes, an animation timeline, AR and VR. The registry and the
single-canvas structure are what make these additions rather than rewrites.

The reference asset's licence is **not verified**. The page renders that status
rather than hiding it, and the model should be treated as development-only
until its terms are confirmed.

---

Aircraft figures are from
[militaryfactory.com](https://www.militaryfactory.com/aircraft/detail.php?aircraft_id=93).
Service ceiling is deliberately omitted: the figure published there
(1,532 ft) is not consistent with the quoted 2,400 ft/min rate of climb, and a
suspect number is worse than a missing one.
