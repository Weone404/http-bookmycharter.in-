import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwind from '@tailwindcss/vite';
import { fileURLToPath, URL } from 'node:url';

export default defineConfig({
  plugins: [react(), tailwind()],
  resolve: {
    alias: { '@': fileURLToPath(new URL('./src', import.meta.url)) },
  },
  build: {
    target: 'es2022',
    // Three.js, the R3F reconciler and drei are large and none of them are
    // needed to paint the page shell. Splitting them keeps the first chunk
    // small enough that the headline and navigation render while the engine
    // is still arriving.
    rollupOptions: {
      output: {
        manualChunks(id: string) {
          if (!id.includes('node_modules')) return undefined;
          if (id.includes('three/build') || id.includes('three/examples')) return 'three';
          if (id.includes('@react-three')) return 'r3f';
          if (id.includes('/gsap/')) return 'gsap';
          return undefined;
        },
      },
    },
    chunkSizeWarningLimit: 900,
  },
  // .glb is served as an asset, never inlined — a 7 MB base64 string in a JS
  // chunk would defeat the entire compression pipeline.
  assetsInclude: ['**/*.glb', '**/*.hdr'],
});
