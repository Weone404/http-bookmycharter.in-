#!/usr/bin/env node
/**
 * The model pipeline. This is the script that actually produced the two files
 * in `public/models/optimized/`, not a description of one.
 *
 * Usage:
 *   node scripts/optimize-model.mjs <input.glb> <output.glb> [maxTexturePx]
 *
 * Measured on the SA 342M Gazelle supplied as the reference asset:
 *
 *   input   93.8 MB   97 meshes · 92 materials · 103 textures · 512,136 tris
 *   1024px   7.3 MB   91 meshes · 91 materials · 100 textures · 512,136 tris
 *    512px   4.7 MB   91 meshes · 91 materials · 100 textures · 512,136 tris
 *
 * Note what did NOT change: the triangle count. No decimation is performed and
 * none is wanted. A 92% reduction is available from vertex encoding and
 * texture format alone, and simplification is the one step that is visible, so
 * it is the last one to reach for rather than the first.
 *
 * The order matters. dedup before join, because joining first hides the
 * duplicates. prune after both, because the earlier steps are what orphan the
 * nodes worth pruning. Texture compression last among the data steps, so it
 * only ever runs on textures that survived.
 *
 * Known gap, stated rather than hidden: this emits WebP, not KTX2/Basis. WebP
 * is smaller on disk but decodes to full RGBA in GPU memory — roughly 400 MB
 * for this model's 100 textures at 1024px, about 100 MB at 512px. KTX2 stays
 * compressed on the GPU and is the real fix for mobile, but it needs the
 * KTX-Software binaries (`toktx`) on PATH. Install them and add the `toktx`
 * transform here; nothing else in the project changes.
 */
import { NodeIO } from '@gltf-transform/core';
import { ALL_EXTENSIONS } from '@gltf-transform/extensions';
import {
  dedup,
  draco,
  flatten,
  instance,
  join,
  prune,
  resample,
  textureCompress,
  weld,
} from '@gltf-transform/functions';
import draco3d from 'draco3d';
import sharp from 'sharp';
import { statSync } from 'node:fs';

const [input, output, maxTextureArg] = process.argv.slice(2);
if (!input || !output) {
  console.error('usage: node scripts/optimize-model.mjs <input.glb> <output.glb> [maxTexturePx]');
  process.exit(1);
}
const maxTexture = Number(maxTextureArg ?? 1024);

const io = new NodeIO().registerExtensions(ALL_EXTENSIONS).registerDependencies({
  'draco3d.encoder': await draco3d.createEncoderModule(),
  'draco3d.decoder': await draco3d.createDecoderModule(),
});

const started = Date.now();
const doc = await io.read(input);

const census = (label) => {
  const root = doc.getRoot();
  let triangles = 0;
  for (const mesh of root.listMeshes()) {
    for (const prim of mesh.listPrimitives()) {
      const indices = prim.getIndices();
      const position = prim.getAttribute('POSITION');
      triangles += indices ? indices.getCount() / 3 : position ? position.getCount() / 3 : 0;
    }
  }
  return {
    label,
    meshes: root.listMeshes().length,
    materials: root.listMaterials().length,
    textures: root.listTextures().length,
    triangles: Math.round(triangles),
  };
};

const before = census('before');

await doc.transform(
  dedup(),
  instance({ min: 2 }),
  flatten(),
  dedup(),
  join({ keepNamed: false }),
  weld(),
  resample(),
  prune({ keepAttributes: false, keepLeaves: false }),
  textureCompress({
    encoder: sharp,
    targetFormat: 'webp',
    resize: [maxTexture, maxTexture],
    quality: 82,
  }),
  draco({ method: 'edgebreaker' }),
);

await io.write(output, doc);

const after = census('after');
const mb = (bytes) => (bytes / 1048576).toFixed(1) + ' MB';

console.log(`input   ${mb(statSync(input).size)}`, before);
console.log(`output  ${mb(statSync(output).size)}`, after);
if (before.triangles !== after.triangles) {
  console.warn(
    `WARNING: triangle count changed (${before.triangles} -> ${after.triangles}). ` +
      'This pipeline is not supposed to decimate; check which transform did it.',
  );
}
console.log(`took ${((Date.now() - started) / 1000).toFixed(0)}s`);
